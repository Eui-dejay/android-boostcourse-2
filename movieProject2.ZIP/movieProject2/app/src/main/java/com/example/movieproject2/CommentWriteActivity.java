package com.example.movieproject2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Rating;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;

import com.example.movieproject2.R;

public class CommentWriteActivity extends AppCompatActivity {
    RatingBar ratingBar;
    EditText contentsInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment_write);

        ratingBar = (RatingBar) findViewById(R.id.ratingBar);
        contentsInput = (EditText) findViewById(R.id.contentsInput);

        saveCancel();

        Intent intent = getIntent();
        showAverageRating(intent);
    }

    public void saveCancel(){
        Button cancleButton =  (Button) findViewById(R.id.cancelButton);
        cancleButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                finish();
            }
        });
        //저장 버튼 누를 시에 메인화면으로 돌아가는 함수 호출
        Button saveButton = (Button) findViewById(R.id.saveButton);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                returnToMain();
            }
        });
    }

    //메인의 평균 별점에서 뽑아와서 디폴트로 평균 별점 보여주기
    private void showAverageRating(Intent intent) {
        if(intent != null) {
            //float 값받아서 ratingBar에 레이팅 셋
            float rating = intent.getFloatExtra("rating", 0.0f);
            ratingBar.setRating(rating);
        }
    }

    //메인으로 돌아가는 함수
    public void returnToMain() {
        String contents = contentsInput.getText().toString();
        Float reviewRating = ratingBar.getRating();
        if(contents.length() > 0)
        {
            //인텐트로 contents 넘겨주기
            Intent intent = new Intent();
            intent.putExtra("contents", contents);
            intent.putExtra("rating", reviewRating);
            setResult(RESULT_OK, intent);
        }

        //보조창 닫기
        finish();
    }
}

package com.example.movieproject2;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import androidx.annotation.Nullable;

public class ReviewerItemView extends LinearLayout {

    TextView textViewId;
    TextView textViewReview;
    RatingBar ratingBarSmall;
    public ReviewerItemView(Context context) {
        super(context);

        init(context);
    }

    public ReviewerItemView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        init(context);
    }

    private void init(Context context) {
        //xml에 정의된 Resource 뷰로 변환
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.reviewer_item,this,true);

        textViewId = (TextView) findViewById(R.id.textViewId);
        textViewReview = (TextView) findViewById(R.id.textViewReview);
        ratingBarSmall = (RatingBar) findViewById(R.id.ratingBarSmall);
    }
    //이름 설정
    public void setName(String name) {
        textViewId.setText(name);
    }
    //리뷰 텍스트 설정
    public void setTextViewReview(String reviewText) {
        textViewReview.setText(reviewText);
    }

    public void setRatingBarSmall(Float Rating) { ratingBarSmall.setRating(Rating); }
}

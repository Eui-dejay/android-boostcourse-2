package com.example.movieproject2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.Toast;

import com.example.movieproject2.MainActivity.ReviewerAdapter;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import static android.R.*;

public class reviewListActivity extends AppCompatActivity {

    String contents;
    float reviewRating;
    ReviewerAdapter2 adapter2;
    //Intent items;
    ArrayList<ReviewerItem> items;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_list);

        //ArrayList<ReviewerItem> 형식의 items 변수에 본문 ListView 인자 전달
        items = getIntent().getParcelableArrayListExtra("items");

        adapter2 = new ReviewerAdapter2();

        ListView reviewListView = (ListView) findViewById(R.id.reviewListView);

        adapter2.items = items;

        reviewListView.setAdapter(adapter2);

        moveToReview();
    }

    public void moveToReview(){
        Button reviewButton = (Button) findViewById(R.id.reviewButton);
        reviewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),CommentWriteActivity.class);
                //intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivityForResult(intent,112);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);

        if (requestCode == 112) {
            if (intent != null) {
                contents = intent.getStringExtra("contents");
                reviewRating = intent.getFloatExtra("rating", 5.0f);
                Intent intentToMain = new Intent();
                intentToMain.putExtra("contents",contents);
                intentToMain.putExtra("rating",reviewRating);
                setResult(RESULT_OK, intent);
            }
            finish();
        }
    }

    class ReviewerAdapter2 extends BaseAdapter {
        ArrayList<ReviewerItem> items = new ArrayList<ReviewerItem>();

        @Override
        public int getCount() {
            return items.size();
        } //아이템 개수 반환

        public void addItem(ReviewerItem item) {
            items.add(item);
        }

        @Override
        public Object getItem(int position) {
            return  items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ReviewerItemView view = null;

            if(convertView == null) {
                view = new ReviewerItemView(getApplicationContext());
            } else {
                view = (ReviewerItemView) convertView;
            }

            ReviewerItem item = items.get(position);
            view.setName(item.getName());
            view.setTextViewReview(item.getReviewText());
            view.setRatingBarSmall(item.getRating());
            return view;
        }
    }
}

package com.example.movieproject2;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    final ReviewerAdapter adapter = new ReviewerAdapter();
    RatingBar ratingBar;
    ListView listView;
    String contents;
    Float reviewRating;
    TextView upRateView;
    TextView downRateView;
    Button likeButton;
    Button dislikeButton;
    boolean likeState = false;
    boolean dislikeState = false;
    int likeCount = 15;
    int dislikeCount = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        upRateView = (TextView) findViewById(R.id.upRateView);
        downRateView = (TextView) findViewById(R.id.downRateView);
        listView = (ListView) findViewById(R.id.listView);

       //기본 아이템 추가
        adapter.addItem(new ReviewerItem("asd***","적당히 재밌다, 오랜만에 잠 안오는 영화 봤네요", (float) 5.));  //어댑터를 이용한 리스트뷰에 아이템 추가
        adapter.addItem(new ReviewerItem("bba***","영화가 너무 재밌어요 모두 추천드려요", (float) 5.));
        adapter.addItem(new ReviewerItem("asd***","적당히 재밌다, 오랜만에 잠 안오는 영화 봤네요", (float) 4.2));
        adapter.items.add(3,(new ReviewerItem("asd***","와!", (float) 3.5)));
        listView.setAdapter(adapter);


        //난잡해보여서 우선은 onCreate()에서 내리고 함수로 따로 뺀 기능들
        smallListScroll();
        thumbState();
        reviewButtonClick();
        reviewButton();
        showAllReviewButton(adapter.items);
    }

    //Intent 받아서 어댑터로 추가 테스트 끝
    /*public void addReview(String String) {
        try{
            adapter.addItem(new ReviewerItem("asd",String));
        }
        catch (Exception e)
        {
            Toast.makeText(this,"errorFromAdd", Toast.LENGTH_LONG).show();
        }
        try{
            //listView.setAdapter(adapter);
        }
        catch (Exception e)
        {
            Toast.makeText(this,"errorShow", Toast.LENGTH_LONG).show();
        }
    }*/

    public void reviewButton() {
        ratingBar = (RatingBar) findViewById(R.id.ratingBarSmall);

        Button button = (Button) findViewById(R.id.reviewButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCommentWriteActivity();
            }
        });
    }
    public void showCommentWriteActivity() {
        float rating = ratingBar.getRating();

        Intent intent = new Intent(getApplicationContext(),CommentWriteActivity.class);
        //intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra("rating", rating);

        startActivityForResult(intent, 101);
    }


    public void showAllReviewButton(final ArrayList<ReviewerItem> items){
        Button button = (Button) findViewById(R.id.showAllReview);
        button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(getApplicationContext(), reviewListActivity.class);
                //intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                intent.putParcelableArrayListExtra("items",items);
                startActivityForResult(intent, 111);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);

        if (requestCode == 101) {
            if (intent != null) {
                contents = intent.getStringExtra("contents");
                reviewRating = intent.getFloatExtra("rating", 5.0f);
                try
                {
                    //addReview(contents);
                    adapter.addItem(new ReviewerItem("ad", contents, reviewRating));
                    listView.setAdapter(adapter);
                }
                catch (Exception e)
                {
                    Toast.makeText(this,"error" ,Toast.LENGTH_LONG).show();
                }
            }
        }
        if (requestCode == 111) {
            if (intent != null) {
                contents = intent.getStringExtra("contents");
                reviewRating = intent.getFloatExtra("rating", 5.0f);
                try
                {
                    //addReview(contents);
                    adapter.addItem(new ReviewerItem("far***", contents, reviewRating));
                    listView.setAdapter(adapter);
                }
                catch (Exception e)
                {
                    Toast.makeText(this,"error" ,Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    private void smallListScroll() {
        ListView mListView = (ListView) findViewById(R.id.listView);
        final ScrollView mScrollView = (ScrollView) findViewById(R.id.scrollView);
        mListView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                mScrollView.requestDisallowInterceptTouchEvent(true);
                int action = event.getActionMasked();
                switch (action) {
                    case MotionEvent.ACTION_UP:
                        mScrollView.requestDisallowInterceptTouchEvent(false);
                        break;
                }
                return false;
            }
        });
    }                //미니 스크롤 뷰 스크롤 할때 기본 스크롤 뷰 기능 정지
    private void reviewButtonClick() {
        Button button = (Button) findViewById(R.id.reviewButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast toast = Toast.makeText(getApplicationContext(), "작성하기 버튼 눌림", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.BOTTOM,0,200);
                toast.show();
            }
        });
    }               //버튼 클릭 시에 토스트 메세지 출력
    private void thumbState() {
        likeButton = (Button) findViewById(R.id.likeButton);
        dislikeButton = (Button) findViewById(R.id.dislikeButton);
        likeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(dislikeState) {
                    dislikeState = !dislikeState;
                    decrDislikeCount();
                    incrLikeCount();
                } else {
                    if (likeState) {
                        decrLikeCount();
                    } else {
                        incrLikeCount();
                    }
                }
                likeState = !likeState;
            }
        });

        dislikeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(likeState) {
                    likeState = !likeState;
                    decrLikeCount();
                    incrDislikeCount();

                } else {
                    if (dislikeState) {
                        decrDislikeCount();
                    } else {
                        incrDislikeCount();
                    }
                }
                dislikeState = !dislikeState;
            }
        });
    }                       //좋아요나 싫어요 버튼이 눌렸는지 boolean 으로 검사 후 알맞게 함수 출력
    private void incrLikeCount() {
            likeCount += 1;
            upRateView.setText(String.valueOf(likeCount));

            likeButton.setBackgroundResource(R.drawable.ic_thumb_up_selected);
    }                   //좋아요 카운트를 를 하나 증가
    private void decrLikeCount() {
        likeCount -= 1;
        upRateView.setText(String.valueOf(likeCount));

        likeButton.setBackgroundResource(R.drawable.ic_thumb_up);
        }                   //좋아요 카운트를 하나 감소
    private void incrDislikeCount() {
            dislikeCount += 1;
            downRateView.setText(String.valueOf(dislikeCount));

            dislikeButton.setBackgroundResource(R.drawable.ic_thumb_down_selected);

        }                //싫어요 카운트를 하나 증가
    private void decrDislikeCount() {
        dislikeCount -= 1;
        downRateView.setText(String.valueOf(dislikeCount));

        dislikeButton.setBackgroundResource(R.drawable.ic_thumb_down);
    }                //싫어요 카운트를 하나 감소

    class ReviewerAdapter extends BaseAdapter {
        ArrayList<ReviewerItem> items = new ArrayList<ReviewerItem>();

        @Override
        public int getCount() {
            return items.size();
        } //아이템 개수 반환

        public void addItem(ReviewerItem item) {
            items.add(item);
        }

        @Override
        public Object getItem(int position) {
            return  items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ReviewerItemView view = null;

            if(convertView == null) {
                view = new ReviewerItemView(getApplicationContext());
            } else {
                view = (ReviewerItemView) convertView;
            }

            ReviewerItem item = items.get(position);
            view.setName(item.getName());
            view.setTextViewReview(item.getReviewText());
            view.setRatingBarSmall(item.getRating());

            return view;
        }
    }
}

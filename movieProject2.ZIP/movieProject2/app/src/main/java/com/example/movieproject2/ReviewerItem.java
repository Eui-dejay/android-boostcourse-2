package com.example.movieproject2;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class ReviewerItem extends ArrayList<ReviewerItem> implements Parcelable
{

    String name;
    String reviewText;
    Float rating;

    public ReviewerItem(String name, String reviewText, Float rating)
    {
        this.name = name;
        this.reviewText = reviewText;
        this.rating = rating;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getReviewText()
    {
        return reviewText;
    }

    public void setReviewText(String reviewText)
    {
        this.reviewText = reviewText;
    }

    public Float getRating()
    {
        return rating;
    }

    public void setRating(Float rating) { this.rating = rating; }

    @Override
    public String toString()
    {
        return "ReviewerItem{" +
                "name='" + name + '\'' +
                ", reviewText='" + reviewText + '\'' +
                '}';
    }


    public ReviewerItem(Parcel in)
    {
        name = in.readString();
        reviewText = in.readString();
        rating = in.readFloat();
    }
    //Parcelable 에 쓸 CREATOR
    public static final Parcelable.Creator<ReviewerItem> CREATOR = new Parcelable.Creator<ReviewerItem>()
    {

        @Override
        public ReviewerItem createFromParcel(Parcel in)
        {
            return new ReviewerItem(in);
        }

        @Override
        public ReviewerItem[] newArray(int size)
        {
            return new ReviewerItem[size];
        }
    };



    @Override
    public int describeContents()
    {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i)
    {
        parcel.writeString(name);
        parcel.writeString(reviewText);
        parcel.writeFloat(rating);
    }
}




